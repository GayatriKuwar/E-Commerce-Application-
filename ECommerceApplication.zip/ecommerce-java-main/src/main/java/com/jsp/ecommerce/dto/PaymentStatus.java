package com.jsp.ecommerce.dto;

public enum PaymentStatus {
	PENDING,FAILED,PAID
}
