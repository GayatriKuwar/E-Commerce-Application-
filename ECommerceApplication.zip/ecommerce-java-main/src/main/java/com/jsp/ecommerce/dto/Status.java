package com.jsp.ecommerce.dto;

public enum Status {
	PENDING,APPROVED,REJECTED
}
