package com.jsp.ecommerce.dto;

public enum OrderStatus {
	PLACED, SHIPPED, DELIVERED, CANCELLED,PROCESSING
}
